package com.example.dbdgen.item;

import com.example.dbdgen.block.TrapBlock;
import com.example.dbdgen.game.GameUtil;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUseContext;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TranslationTextComponent;
import net.minecraft.world.World;

/** Ножницы: ПКМ по верёвке или растяжке перерезает её. */
public class ScissorsItem extends Item {
    public ScissorsItem(Properties props) {
        super(props);
    }

    @Override
    public ActionResultType useOn(ItemUseContext ctx) {
        World world = ctx.getLevel();
        BlockPos pos = ctx.getClickedPos();
        if (!(world.getBlockState(pos).getBlock() instanceof TrapBlock)) return ActionResultType.PASS;
        TrapBlock trap = (TrapBlock) world.getBlockState(pos).getBlock();
        PlayerEntity p = ctx.getPlayer();

        if (!world.isClientSide) {
            if (trap.getKind() == GameUtil.KIND_BEAR) {
                if (p != null) p.displayClientMessage(new TranslationTextComponent("message.dbdgen.need_crowbar"), true);
                return ActionResultType.CONSUME;
            }
            world.removeBlock(pos, false);
            world.playSound(null, pos, SoundEvents.SHEEP_SHEAR, SoundCategory.BLOCKS, 1.0F, 1.0F);
            if (p != null) ctx.getItemInHand().hurtAndBreak(1, p, pl -> pl.broadcastBreakEvent(ctx.getHand()));
        }
        return world.isClientSide ? ActionResultType.SUCCESS : ActionResultType.CONSUME;
    }
}
