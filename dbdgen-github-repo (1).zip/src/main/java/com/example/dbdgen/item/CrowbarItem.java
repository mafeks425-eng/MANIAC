package com.example.dbdgen.item;

import com.example.dbdgen.block.TrapBlock;
import com.example.dbdgen.game.GameUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUseContext;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Hand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TranslationTextComponent;
import net.minecraft.world.World;

/**
 * Лом: ломает капкан (ПКМ по нему), освобождает пойманного игрока (ПКМ по нему),
 * вскрывает запертую дверь и оглушает маньяка ударом.
 */
public class CrowbarItem extends Item {
    public CrowbarItem(Properties props) {
        super(props);
    }

    @Override
    public ActionResultType useOn(ItemUseContext ctx) {
        World world = ctx.getLevel();
        BlockPos pos = ctx.getClickedPos();
        if (!(world.getBlockState(pos).getBlock() instanceof TrapBlock)) return ActionResultType.PASS;
        TrapBlock trap = (TrapBlock) world.getBlockState(pos).getBlock();
        PlayerEntity p = ctx.getPlayer();

        if (!world.isClientSide) {
            if (trap.getKind() != GameUtil.KIND_BEAR) {
                if (p != null) p.displayClientMessage(new TranslationTextComponent("message.dbdgen.need_scissors"), true);
                return ActionResultType.CONSUME;
            }
            world.removeBlock(pos, false);
            world.playSound(null, pos, SoundEvents.ANVIL_USE, SoundCategory.BLOCKS, 0.8F, 1.3F);
            if (p != null) ctx.getItemInHand().hurtAndBreak(1, p, pl -> pl.broadcastBreakEvent(ctx.getHand()));
        }
        return world.isClientSide ? ActionResultType.SUCCESS : ActionResultType.CONSUME;
    }

    @Override
    public ActionResultType interactLivingEntity(ItemStack stack, PlayerEntity player, LivingEntity target, Hand hand) {
        if (!(target instanceof PlayerEntity)) return ActionResultType.PASS;
        if (player.level.isClientSide) return ActionResultType.SUCCESS;
        if (target instanceof ServerPlayerEntity && GameUtil.isTrapped((ServerPlayerEntity) target)) {
            GameUtil.release((ServerPlayerEntity) target);
            player.level.playSound(null, target.blockPosition(), SoundEvents.ANVIL_USE, SoundCategory.PLAYERS, 0.7F, 1.4F);
            stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
        }
        return ActionResultType.CONSUME;
    }
}
