package com.example.dbdgen.item;

import com.example.dbdgen.client.ClientState;
import com.example.dbdgen.game.GameUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.UseAction;
import net.minecraft.util.ActionResult;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Hand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.text.TranslationTextComponent;
import net.minecraft.world.World;

/** Аптечка: +1 жизнь. Себя лечишь 3 секунды (зажать ПКМ), другого - ПКМ по игроку. */
public class MedkitItem extends Item {
    public MedkitItem(Properties props) {
        super(props);
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return 60;
    }

    @Override
    public UseAction getUseAnimation(ItemStack stack) {
        return UseAction.BOW;
    }

    @Override
    public ActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getItemInHand(hand);
        int lives = world.isClientSide ? ClientState.lives : GameUtil.getLives(player);
        if (lives >= GameUtil.MAX_LIVES) {
            if (!world.isClientSide) player.displayClientMessage(new TranslationTextComponent("message.dbdgen.lives_full"), true);
            return ActionResult.fail(stack);
        }
        player.startUsingItem(hand);
        return ActionResult.consume(stack);
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, World world, LivingEntity entity) {
        if (entity instanceof ServerPlayerEntity) {
            ServerPlayerEntity sp = (ServerPlayerEntity) entity;
            if (GameUtil.getLives(sp) < GameUtil.MAX_LIVES) {
                GameUtil.setLives(sp, GameUtil.getLives(sp) + 1);
                world.playSound(null, sp.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundCategory.PLAYERS, 0.6F, 1.5F);
                sp.displayClientMessage(new TranslationTextComponent("message.dbdgen.life_restored"), true);
            }
        }
        if (!(entity instanceof PlayerEntity) || !((PlayerEntity) entity).isCreative()) stack.shrink(1);
        return stack;
    }

    @Override
    public ActionResultType interactLivingEntity(ItemStack stack, PlayerEntity player, LivingEntity target, Hand hand) {
        if (!(target instanceof PlayerEntity)) return ActionResultType.PASS;
        if (player.level.isClientSide) return ActionResultType.SUCCESS;
        if (target instanceof ServerPlayerEntity) {
            ServerPlayerEntity sp = (ServerPlayerEntity) target;
            if (!sp.isSpectator() && GameUtil.getLives(sp) < GameUtil.MAX_LIVES) {
                GameUtil.setLives(sp, GameUtil.getLives(sp) + 1);
                sp.displayClientMessage(new TranslationTextComponent("message.dbdgen.life_restored"), true);
                if (!player.isCreative()) stack.shrink(1);
            } else {
                player.displayClientMessage(new TranslationTextComponent("message.dbdgen.lives_full"), true);
            }
        }
        return ActionResultType.CONSUME;
    }
}
