package com.example.dbdgen.item;

import com.example.dbdgen.client.ClientState;
import com.example.dbdgen.game.GameUtil;
import net.minecraft.block.Block;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.text.TranslationTextComponent;

/** Ловушка: не расходуется, после установки уходит на перезарядку. Ставит только маньяк. */
public class TrapItem extends BlockItem {
    private final int cooldown;

    public TrapItem(Block block, Properties props, int cooldown) {
        super(block, props);
        this.cooldown = cooldown;
    }

    @Override
    public ActionResultType place(BlockItemUseContext ctx) {
        PlayerEntity p = ctx.getPlayer();
        boolean client = ctx.getLevel().isClientSide;
        boolean allowed = p == null || p.isCreative()
                || (client ? ClientState.killer : (p instanceof ServerPlayerEntity && GameUtil.isKiller((ServerPlayerEntity) p)));
        if (!allowed) {
            if (!client && p != null) p.displayClientMessage(new TranslationTextComponent("message.dbdgen.only_killer"), true);
            return ActionResultType.FAIL;
        }
        ActionResultType r = super.place(ctx);
        if (r.consumesAction() && p != null) {
            p.getCooldowns().addCooldown(this, cooldown);
            if (!p.isCreative()) ctx.getItemInHand().grow(1); // ловушка не расходуется
        }
        return r;
    }
}
