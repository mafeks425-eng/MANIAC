package com.example.dbdgen.network;

import com.example.dbdgen.client.MiniGameClient;
import net.minecraft.network.PacketBuffer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.network.NetworkEvent;

import java.util.function.Supplier;

/** Сервер -> клиент: запустить мини-игру. type 0 = скилл-чек, 1 = последовательность стрелок. */
public class MiniGamePacket {
    private final int type, seed;
    private final float zoneStart, zoneSize, speed;

    public MiniGamePacket(int type, float zoneStart, float zoneSize, float speed, int seed) {
        this.type = type;
        this.zoneStart = zoneStart;
        this.zoneSize = zoneSize;
        this.speed = speed;
        this.seed = seed;
    }

    public void encode(PacketBuffer b) {
        b.writeInt(type);
        b.writeFloat(zoneStart);
        b.writeFloat(zoneSize);
        b.writeFloat(speed);
        b.writeInt(seed);
    }

    public static MiniGamePacket decode(PacketBuffer b) {
        return new MiniGamePacket(b.readInt(), b.readFloat(), b.readFloat(), b.readFloat(), b.readInt());
    }

    public static void handle(MiniGamePacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
                MiniGameClient.start(m.type, m.zoneStart, m.zoneSize, m.speed, m.seed)));
        ctx.get().setPacketHandled(true);
    }
}
