package com.example.dbdgen.network;

import com.example.dbdgen.game.GameUtil;
import com.example.dbdgen.tile.GeneratorTileEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.network.PacketBuffer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.network.NetworkEvent;

import java.util.function.Supplier;

/** Клиент -> сервер: результат мини-игры. */
public class MiniGameResultPacket {
    private final boolean success;

    public MiniGameResultPacket(boolean success) {
        this.success = success;
    }

    public void encode(PacketBuffer b) {
        b.writeBoolean(success);
    }

    public static MiniGameResultPacket decode(PacketBuffer b) {
        return new MiniGameResultPacket(b.readBoolean());
    }

    public static void handle(MiniGameResultPacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> {
            ServerPlayerEntity sp = c.getSender();
            if (sp == null) return;
            CompoundNBT d = GameUtil.data(sp);
            if (d.getLong("dbd_check_end") == 0) return; // нет активной проверки - игнорируем
            d.putLong("dbd_check_end", 0);
            BlockPos pos = BlockPos.of(d.getLong("dbd_check_pos"));
            if (sp.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) > 64) return;
            TileEntity te = sp.level.getBlockEntity(pos);
            if (te instanceof GeneratorTileEntity && !((GeneratorTileEntity) te).isRepaired()) {
                ((GeneratorTileEntity) te).applyCheckResult(sp, m.success);
            }
        });
        c.setPacketHandled(true);
    }
}
