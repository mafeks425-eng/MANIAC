package com.example.dbdgen.network;

import com.example.dbdgen.DbdGen;
import com.example.dbdgen.game.DbdData;
import com.example.dbdgen.game.GameUtil;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.network.NetworkRegistry;
import net.minecraftforge.fml.network.PacketDistributor;
import net.minecraftforge.fml.network.simple.SimpleChannel;

public class ModNetwork {
    private static final String PROTOCOL = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(DbdGen.MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    public static void register() {
        int id = 0;
        CHANNEL.registerMessage(id++, SyncPacket.class, SyncPacket::encode, SyncPacket::decode, SyncPacket::handle);
        CHANNEL.registerMessage(id++, MiniGamePacket.class, MiniGamePacket::encode, MiniGamePacket::decode, MiniGamePacket::handle);
        CHANNEL.registerMessage(id++, MiniGameResultPacket.class, MiniGameResultPacket::encode, MiniGameResultPacket::decode, MiniGameResultPacket::handle);
        CHANNEL.registerMessage(id++, FlipPacket.class, FlipPacket::encode, FlipPacket::decode, FlipPacket::handle);
    }

    public static void syncPlayer(ServerPlayerEntity p) {
        MinecraftServer s = p.getServer();
        if (s == null) return;
        DbdData d = DbdData.get(s);
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> p),
                new SyncPacket(d.getGens(), DbdData.TOTAL_GENS, d.getSurvivors(),
                        GameUtil.getLives(p), GameUtil.isKiller(p)));
    }

    public static void syncAll(MinecraftServer s) {
        for (ServerPlayerEntity p : s.getPlayerList().getPlayers()) syncPlayer(p);
    }
}
