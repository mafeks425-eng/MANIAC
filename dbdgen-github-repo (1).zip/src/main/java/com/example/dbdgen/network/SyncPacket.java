package com.example.dbdgen.network;

import com.example.dbdgen.client.ClientState;
import net.minecraft.network.PacketBuffer;
import net.minecraftforge.fml.network.NetworkEvent;

import java.util.function.Supplier;

/** Сервер -> клиент: данные для интерфейса. */
public class SyncPacket {
    private final int gens, total, survivors, lives;
    private final boolean killer;

    public SyncPacket(int gens, int total, int survivors, int lives, boolean killer) {
        this.gens = gens;
        this.total = total;
        this.survivors = survivors;
        this.lives = lives;
        this.killer = killer;
    }

    public void encode(PacketBuffer b) {
        b.writeInt(gens);
        b.writeInt(total);
        b.writeInt(survivors);
        b.writeInt(lives);
        b.writeBoolean(killer);
    }

    public static SyncPacket decode(PacketBuffer b) {
        return new SyncPacket(b.readInt(), b.readInt(), b.readInt(), b.readInt(), b.readBoolean());
    }

    public static void handle(SyncPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> ClientState.update(m.gens, m.total, m.survivors, m.lives, m.killer));
        ctx.get().setPacketHandled(true);
    }
}
