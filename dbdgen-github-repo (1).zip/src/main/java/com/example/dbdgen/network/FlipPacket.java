package com.example.dbdgen.network;

import com.example.dbdgen.client.ClientState;
import net.minecraft.network.PacketBuffer;
import net.minecraftforge.fml.network.NetworkEvent;

import java.util.UUID;
import java.util.function.Supplier;

/** Сервер -> все клиенты: перевернуть / вернуть игрока (верёвочная ловушка). */
public class FlipPacket {
    private final UUID id;
    private final boolean flipped;

    public FlipPacket(UUID id, boolean flipped) {
        this.id = id;
        this.flipped = flipped;
    }

    public void encode(PacketBuffer b) {
        b.writeUUID(id);
        b.writeBoolean(flipped);
    }

    public static FlipPacket decode(PacketBuffer b) {
        return new FlipPacket(b.readUUID(), b.readBoolean());
    }

    public static void handle(FlipPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            if (m.flipped) ClientState.flipped.add(m.id);
            else ClientState.flipped.remove(m.id);
        });
        ctx.get().setPacketHandled(true);
    }
}
