package com.example.dbdgen.block;

import com.example.dbdgen.game.DbdData;
import com.example.dbdgen.game.Exit;
import com.example.dbdgen.game.GameUtil;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Hand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.util.text.TranslationTextComponent;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;

/**
 * Рычаг побега. На старте матча из всех поставленных рычагов остаётся один (PRESENT),
 * остальные пропадают. Работает только когда починены все генераторы.
 * Открывает выход своего маршрута (подвал или пещера).
 */
public class ExitLeverBlock extends Block {
    public static final BooleanProperty PRESENT = BooleanProperty.create("present"); // рычаг есть на карте
    public static final BooleanProperty PULLED = BooleanProperty.create("pulled");   // уже дёрнут
    private static final VoxelShape SHAPE = Block.box(4, 0, 4, 12, 15, 12);

    private final int route;

    public ExitLeverBlock(int route) {
        super(AbstractBlock.Properties.of(Material.METAL).strength(-1.0F, 3600000.0F)
                .sound(SoundType.METAL).noOcclusion());
        this.route = route;
        registerDefaultState(stateDefinition.any().setValue(PRESENT, true).setValue(PULLED, false));
    }

    public int getRoute() {
        return route;
    }

    @Override
    protected void createBlockStateDefinition(StateContainer.Builder<Block, BlockState> builder) {
        builder.add(PRESENT, PULLED);
    }

    @Override
    public VoxelShape getShape(BlockState state, IBlockReader world, BlockPos pos, ISelectionContext ctx) {
        return state.getValue(PRESENT) ? SHAPE : VoxelShapes.empty();
    }

    @Override
    public ActionResultType use(BlockState state, World world, BlockPos pos, PlayerEntity player,
                                Hand hand, BlockRayTraceResult hit) {
        if (!state.getValue(PRESENT)) return ActionResultType.PASS;
        if (world.isClientSide) return ActionResultType.SUCCESS;
        if (state.getValue(PULLED) || !(player instanceof ServerPlayerEntity)) return ActionResultType.CONSUME;

        ServerPlayerEntity sp = (ServerPlayerEntity) player;
        MinecraftServer server = world.getServer();
        if (server == null) return ActionResultType.CONSUME;

        if (GameUtil.isKiller(sp)) {
            sp.displayClientMessage(new TranslationTextComponent("message.dbdgen.lever_killer"), true);
            return ActionResultType.CONSUME;
        }
        if (DbdData.get(server).getGens() < DbdData.TOTAL_GENS) {
            world.playSound(null, pos, SoundEvents.LEVER_CLICK, SoundCategory.BLOCKS, 1.0F, 0.5F);
            sp.displayClientMessage(new TranslationTextComponent("message.dbdgen.no_power"), true);
            return ActionResultType.CONSUME;
        }

        world.setBlock(pos, state.setValue(PULLED, true), 3);
        world.playSound(null, pos, SoundEvents.LEVER_CLICK, SoundCategory.BLOCKS, 1.0F, 0.6F);
        Exit.open(server, route);
        return ActionResultType.CONSUME;
    }

    @Override
    public void onPlace(BlockState state, World world, BlockPos pos, BlockState oldState, boolean moved) {
        if (!world.isClientSide && world.getServer() != null) {
            DbdData.get(world.getServer()).addPoint(DbdData.LEVER, world, pos);
        }
    }

    @Override
    public void onRemove(BlockState state, World world, BlockPos pos, BlockState newState, boolean moved) {
        if (!state.is(newState.getBlock()) && !world.isClientSide && world.getServer() != null) {
            DbdData.get(world.getServer()).removePoint(DbdData.LEVER, world, pos);
        }
        super.onRemove(state, world, pos, newState, moved);
    }
}
