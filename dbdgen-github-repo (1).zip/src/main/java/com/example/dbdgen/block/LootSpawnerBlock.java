package com.example.dbdgen.block;

import com.example.dbdgen.game.DbdData;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Точка лута: ящик, на котором команда /dbd loot fill раскладывает предметы. */
public class LootSpawnerBlock extends Block {

    public LootSpawnerBlock() {
        super(AbstractBlock.Properties.of(Material.WOOD).strength(2.0F).sound(SoundType.WOOD));
    }

    @Override
    public void onPlace(BlockState state, World world, BlockPos pos, BlockState oldState, boolean moved) {
        if (!world.isClientSide && world.getServer() != null) {
            DbdData.get(world.getServer()).addLoot(world, pos);
        }
    }

    @Override
    public void onRemove(BlockState state, World world, BlockPos pos, BlockState newState, boolean moved) {
        if (!state.is(newState.getBlock()) && !world.isClientSide && world.getServer() != null) {
            DbdData.get(world.getServer()).removeLoot(world, pos);
        }
        super.onRemove(state, world, pos, newState, moved);
    }
}
