package com.example.dbdgen.block;

import com.example.dbdgen.game.DbdData;
import com.example.dbdgen.game.GameUtil;
import com.example.dbdgen.init.ModItems;
import com.example.dbdgen.tile.GeneratorTileEntity;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Direction;
import net.minecraft.util.Hand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.text.TranslationTextComponent;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import java.util.Random;

public class GeneratorBlock extends Block {
    public static final BooleanProperty LIT = BlockStateProperties.LIT;               // починен и работает
    public static final BooleanProperty FUELED = BooleanProperty.create("fueled");    // бак полон
    private static final VoxelShape SHAPE = Block.box(1, 0, 1, 15, 16, 15);

    public GeneratorBlock() {
        super(AbstractBlock.Properties.of(Material.METAL)
                .strength(3.5F)
                .sound(SoundType.METAL)
                .noOcclusion()
                .lightLevel(s -> s.getValue(LIT) ? 13 : 0));
        registerDefaultState(stateDefinition.any().setValue(LIT, false).setValue(FUELED, false));
    }

    @Override
    protected void createBlockStateDefinition(StateContainer.Builder<Block, BlockState> builder) {
        builder.add(LIT, FUELED);
    }

    @Override
    public VoxelShape getShape(BlockState state, IBlockReader world, BlockPos pos, ISelectionContext ctx) {
        return SHAPE;
    }

    @Override
    public boolean hasTileEntity(BlockState state) {
        return true;
    }

    @Override
    public TileEntity createTileEntity(BlockState state, IBlockReader world) {
        return new GeneratorTileEntity();
    }

    @Override
    public ActionResultType use(BlockState state, World world, BlockPos pos, PlayerEntity player,
                                Hand hand, BlockRayTraceResult hit) {
        if (world.isClientSide) return ActionResultType.SUCCESS;
        TileEntity te = world.getBlockEntity(pos);
        if (!(te instanceof GeneratorTileEntity) || !(player instanceof ServerPlayerEntity)) return ActionResultType.PASS;
        GeneratorTileEntity gen = (GeneratorTileEntity) te;
        ServerPlayerEntity sp = (ServerPlayerEntity) player;
        ItemStack stack = player.getItemInHand(hand);

        if (GameUtil.isKiller(sp)) {
            sp.displayClientMessage(new TranslationTextComponent("message.dbdgen.killer_no"), true);
            return ActionResultType.CONSUME;
        }
        if (GameUtil.isHeld(sp)) return ActionResultType.CONSUME; // пойманный не чинит

        if (gen.isRepaired()) {
            sp.displayClientMessage(new TranslationTextComponent("message.dbdgen.status"), true);
            return ActionResultType.CONSUME;
        }

        // ---------- ЗАПРАВКА: 1% за нажатие, тратится 1 единица канистры ----------
        if (stack.getItem() == ModItems.FUEL_CAN.get()) {
            if (gen.getFuel() >= GeneratorTileEntity.MAX_FUEL) {
                sp.displayClientMessage(new TranslationTextComponent("message.dbdgen.full"), true);
            } else {
                gen.addFuel(1);
                world.playSound(null, pos, SoundEvents.BUCKET_FILL, SoundCategory.BLOCKS,
                        0.4F, 1.0F + gen.getFuel() / 100.0F);
                stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
                sp.displayClientMessage(new TranslationTextComponent("message.dbdgen.fueled", gen.getFuel()), true);
            }
            return ActionResultType.CONSUME;
        }

        // ---------- РЕМОНТ: только с полным баком, топливо не тратится ----------
        if (gen.getFuel() < GeneratorTileEntity.MAX_FUEL) {
            sp.displayClientMessage(new TranslationTextComponent("message.dbdgen.need_fuel", gen.getFuel()), true);
            return ActionResultType.CONSUME;
        }
        gen.repairStep(sp, stack.getItem() == ModItems.WRENCH.get());
        return ActionResultType.CONSUME;
    }

    @Override
    public void onPlace(BlockState state, World world, BlockPos pos, BlockState oldState, boolean moved) {
        if (!world.isClientSide && world.getServer() != null) {
            DbdData.get(world.getServer()).addGenerator(world, pos);
        }
    }

    @Override
    public void onRemove(BlockState state, World world, BlockPos pos, BlockState newState, boolean moved) {
        if (!state.is(newState.getBlock()) && !world.isClientSide && world.getServer() != null) {
            DbdData.get(world.getServer()).removeGenerator(world, pos);
        }
        super.onRemove(state, world, pos, newState, moved);
    }

    // Починенный генератор даёт сигнал редстоуна
    @Override
    public boolean isSignalSource(BlockState state) {
        return true;
    }

    @Override
    public int getSignal(BlockState state, IBlockReader world, BlockPos pos, Direction side) {
        return state.getValue(LIT) ? 15 : 0;
    }

    @Override
    @OnlyIn(Dist.CLIENT)
    public void animateTick(BlockState state, World world, BlockPos pos, Random rand) {
        double x = pos.getX() + 0.3 + rand.nextDouble() * 0.4;
        double z = pos.getZ() + 0.3 + rand.nextDouble() * 0.4;
        double y = pos.getY() + 1.0;
        if (state.getValue(LIT)) {
            if (rand.nextInt(4) == 0) world.addParticle(ParticleTypes.SMOKE, x, y, z, 0, 0.04, 0);
        } else if (!state.getValue(FUELED) && rand.nextInt(10) == 0) {
            world.addParticle(ParticleTypes.CRIT, x, y - 0.3, z, 0, 0.1, 0);
        }
    }
}
