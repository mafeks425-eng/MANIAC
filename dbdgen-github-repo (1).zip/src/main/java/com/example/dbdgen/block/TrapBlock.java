package com.example.dbdgen.block;

import com.example.dbdgen.game.GameUtil;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.util.Direction;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.text.TranslationTextComponent;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReader;
import net.minecraft.world.World;

/**
 * Ловушка маньяка: ловит выжившего на время, потом отпускает с тошнотой.
 * Рукой не ломается: капкан ломают ломом, верёвку и растяжку режут ножницами.
 */
public class TrapBlock extends Block {
    private final int stunTicks;
    private final VoxelShape shape;
    private final int kind;

    public TrapBlock(int stunTicks, VoxelShape shape, int kind) {
        super(AbstractBlock.Properties.of(Material.METAL).strength(-1.0F, 3600000.0F)
                .sound(SoundType.METAL).noCollission().noOcclusion());
        this.stunTicks = stunTicks;
        this.shape = shape;
        this.kind = kind;
    }

    public int getKind() {
        return kind;
    }

    @Override
    public VoxelShape getShape(BlockState state, IBlockReader world, BlockPos pos, ISelectionContext ctx) {
        return shape;
    }

    @Override
    public boolean canSurvive(BlockState state, IWorldReader world, BlockPos pos) {
        BlockPos below = pos.below();
        return world.getBlockState(below).isFaceSturdy(world, below, Direction.UP);
    }

    @Override
    public BlockState updateShape(BlockState state, Direction dir, BlockState neighbor,
                                  IWorld world, BlockPos pos, BlockPos neighborPos) {
        return dir == Direction.DOWN && !canSurvive(state, world, pos) ? Blocks.AIR.defaultBlockState() : state;
    }

    @Override
    public void entityInside(BlockState state, World world, BlockPos pos, Entity entity) {
        if (world.isClientSide || !(entity instanceof ServerPlayerEntity)) return;
        ServerPlayerEntity p = (ServerPlayerEntity) entity;
        if (p.isSpectator() || GameUtil.isKiller(p) || GameUtil.isHeld(p)) return;

        world.removeBlock(pos, false);
        world.playSound(null, pos, SoundEvents.IRON_TRAPDOOR_CLOSE, SoundCategory.BLOCKS, 1.0F, 0.6F);
        GameUtil.startTrapHold(p, pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, stunTicks, kind);
        p.displayClientMessage(new TranslationTextComponent("message.dbdgen.trapped"), true);
    }
}
