package com.example.dbdgen.block;

import com.example.dbdgen.game.DbdData;
import com.example.dbdgen.init.ModItems;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.state.properties.DoubleBlockHalf;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Hand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.text.TranslationTextComponent;
import net.minecraft.world.World;

/**
 * Дверь открывается только ключ-картой (или ломом).
 * Закрыта в начале матча (/dbd start). Открытая остаётся открытой до следующего матча.
 */
public class KeycardDoorBlock extends DoorBlock {

    public KeycardDoorBlock() {
        // Material.WOOD нужен, чтобы ванильная дверь реагировала на ПКМ рукой
        super(AbstractBlock.Properties.of(Material.WOOD).strength(10.0F).sound(SoundType.METAL).noOcclusion());
    }

    @Override
    public ActionResultType use(BlockState state, World world, BlockPos pos, PlayerEntity player,
                                Hand hand, BlockRayTraceResult hit) {
        // открытую дверь закрыть нельзя - она закроется только при /dbd start
        if (state.getValue(OPEN)) {
            return world.isClientSide ? ActionResultType.SUCCESS : ActionResultType.CONSUME;
        }

        Item item = player.getItemInHand(hand).getItem();
        boolean card = item == ModItems.KEYCARD.get();
        boolean crowbar = item == ModItems.CROWBAR.get();
        if (!card && !crowbar) {
            if (!world.isClientSide) {
                world.playSound(null, pos, SoundEvents.LEVER_CLICK, SoundCategory.BLOCKS, 1.0F, 0.5F);
                player.displayClientMessage(new TranslationTextComponent("message.dbdgen.locked"), true);
            }
            return world.isClientSide ? ActionResultType.SUCCESS : ActionResultType.CONSUME;
        }
        if (crowbar && !world.isClientSide) {
            player.getItemInHand(hand).hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
        }
        return super.use(state, world, pos, player, hand, hit);
    }

    /** Редстоун дверь не открывает: только ключ-карта или лом. */
    @Override
    public void neighborChanged(BlockState state, World world, BlockPos pos, Block block, BlockPos fromPos, boolean moved) {
    }

    @Override
    public void onPlace(BlockState state, World world, BlockPos pos, BlockState oldState, boolean moved) {
        if (!world.isClientSide && world.getServer() != null && state.getValue(HALF) == DoubleBlockHalf.LOWER) {
            DbdData.get(world.getServer()).addPoint(DbdData.DOOR, world, pos);
        }
    }

    @Override
    public void onRemove(BlockState state, World world, BlockPos pos, BlockState newState, boolean moved) {
        if (!state.is(newState.getBlock()) && !world.isClientSide && world.getServer() != null
                && state.getValue(HALF) == DoubleBlockHalf.LOWER) {
            DbdData.get(world.getServer()).removePoint(DbdData.DOOR, world, pos);
        }
        super.onRemove(state, world, pos, newState, moved);
    }
}
