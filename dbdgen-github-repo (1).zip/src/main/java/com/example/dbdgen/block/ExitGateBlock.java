package com.example.dbdgen.block;

import com.example.dbdgen.game.DbdData;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;

/** Преграда на пути побега. Закрыта до рычага своего маршрута, потом исчезает (можно пройти). */
public class ExitGateBlock extends Block {
    public static final BooleanProperty OPEN = BlockStateProperties.OPEN;

    private final int route;

    public ExitGateBlock(int route) {
        super(AbstractBlock.Properties.of(Material.METAL).strength(-1.0F, 3600000.0F)
                .sound(SoundType.METAL).noOcclusion());
        this.route = route;
        registerDefaultState(stateDefinition.any().setValue(OPEN, false));
    }

    public int getRoute() {
        return route;
    }

    @Override
    protected void createBlockStateDefinition(StateContainer.Builder<Block, BlockState> builder) {
        builder.add(OPEN);
    }

    @Override
    public VoxelShape getShape(BlockState state, IBlockReader world, BlockPos pos, ISelectionContext ctx) {
        return state.getValue(OPEN) ? VoxelShapes.empty() : VoxelShapes.block();
    }

    @Override
    public void onPlace(BlockState state, World world, BlockPos pos, BlockState oldState, boolean moved) {
        if (!world.isClientSide && world.getServer() != null) {
            DbdData.get(world.getServer()).addPoint(DbdData.GATE, world, pos);
        }
    }

    @Override
    public void onRemove(BlockState state, World world, BlockPos pos, BlockState newState, boolean moved) {
        if (!state.is(newState.getBlock()) && !world.isClientSide && world.getServer() != null) {
            DbdData.get(world.getServer()).removePoint(DbdData.GATE, world, pos);
        }
        super.onRemove(state, world, pos, newState, moved);
    }
}
