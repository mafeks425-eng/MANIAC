package com.example.dbdgen.client;

import com.example.dbdgen.DbdGen;
import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.AbstractGui;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.vector.Vector3f;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderNameplateEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = DbdGen.MODID, value = Dist.CLIENT)
public class ClientEvents {
    private static float flipRoll = 0.0F;
    private static boolean flipPushed = false;

    /** Ники над головами игроков не показываются. */
    @SubscribeEvent
    public static void onNameplate(RenderNameplateEvent e) {
        if (e.getEntity() instanceof PlayerEntity) e.setResult(Event.Result.DENY);
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        MiniGameClient.tick();

        // плавный переворот камеры у игрока, пойманного верёвкой
        Minecraft mc = Minecraft.getInstance();
        float target = (mc.player != null && ClientState.flipped.contains(mc.player.getUUID())) ? 180.0F : 0.0F;
        flipRoll += (target - flipRoll) * 0.25F;
        if (Math.abs(target - flipRoll) < 0.5F) flipRoll = target;
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggedOutEvent e) {
        ClientState.flipped.clear();
        flipRoll = 0.0F;
    }

    @SubscribeEvent
    public static void onCamera(EntityViewRenderEvent.CameraSetup e) {
        if (flipRoll != 0.0F) e.setRoll(e.getRoll() + flipRoll);
    }

    /** Переворачиваем модель игрока вверх ногами. */
    @SubscribeEvent
    public static void onRenderPlayerPre(RenderPlayerEvent.Pre e) {
        PlayerEntity p = e.getPlayer();
        flipPushed = false;
        if (!ClientState.flipped.contains(p.getUUID())) return;
        MatrixStack ms = e.getMatrixStack();
        ms.pushPose();
        flipPushed = true;
        float yaw = MathHelper.rotLerp(e.getPartialRenderTick(), p.yBodyRotO, p.yBodyRot);
        double a = Math.toRadians(180.0F - yaw);
        Vector3f axis = new Vector3f((float) Math.sin(a), 0.0F, (float) Math.cos(a));
        ms.translate(0.0D, p.getBbHeight() + 0.1F, 0.0D);
        ms.mulPose(axis.rotationDegrees(180.0F));
    }

    @SubscribeEvent
    public static void onRenderPlayerPost(RenderPlayerEvent.Post e) {
        if (flipPushed) {
            e.getMatrixStack().popPose();
            flipPushed = false;
        }
    }

    @SubscribeEvent
    public static void onKey(InputEvent.KeyInputEvent e) {
        if (e.getAction() == GLFW.GLFW_PRESS && Minecraft.getInstance().screen == null) {
            MiniGameClient.onKey(e.getKey());
        }
    }

    @SubscribeEvent
    public static void onRender(RenderGameOverlayEvent.Post e) {
        if (e.getType() != RenderGameOverlayEvent.ElementType.ALL) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;

        MatrixStack ms = e.getMatrixStack();
        int x = 8, y = 8;
        int h = ClientState.killer ? 36 : 48;
        AbstractGui.fill(ms, x - 4, y - 4, x + 124, y + h - 4, 0x88000000);

        // Генераторы: сделано / нужно
        int genColor = ClientState.gens >= ClientState.total ? 0x55FF55 : 0xFFFFFF;
        mc.font.drawShadow(ms, I18n.get("hud.dbdgen.gens", ClientState.gens, ClientState.total), x, y, genColor);
        // Сколько людей осталось
        mc.font.drawShadow(ms, I18n.get("hud.dbdgen.survivors", ClientState.survivors), x, y + 12, 0xFFFFFF);

        if (ClientState.killer) {
            mc.font.drawShadow(ms, I18n.get("hud.dbdgen.killer"), x, y + 24, 0xFF5555);
        } else {
            // 3 жизни
            for (int i = 0; i < 3; i++) {
                int color = i < ClientState.lives ? 0xFF3333 : 0x555555;
                mc.font.drawShadow(ms, "\u2764", x + i * 12, y + 26, color);
            }
        }

        MiniGameClient.render(ms, e.getPartialTicks(),
                mc.getWindow().getGuiScaledWidth(), mc.getWindow().getGuiScaledHeight());
    }
}
