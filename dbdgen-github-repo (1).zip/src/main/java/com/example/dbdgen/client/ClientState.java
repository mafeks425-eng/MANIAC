package com.example.dbdgen.client;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Данные для интерфейса (приходят с сервера). Без клиентских классов, поэтому безопасно для сервера. */
public class ClientState {
    public static int gens = 0;
    public static int total = 6;
    public static int survivors = 4;
    public static int lives = 3;
    public static boolean killer = false;

    /** Игроки, которых сейчас "переворачивает" верёвка. */
    public static final Set<UUID> flipped = ConcurrentHashMap.newKeySet();

    public static void update(int g, int t, int s, int l, boolean k) {
        gens = g;
        total = t;
        survivors = s;
        lives = l;
        killer = k;
    }
}
