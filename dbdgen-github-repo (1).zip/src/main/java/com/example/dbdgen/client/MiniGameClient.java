package com.example.dbdgen.client;

import com.example.dbdgen.network.MiniGameResultPacket;
import com.example.dbdgen.network.ModNetwork;
import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.AbstractGui;
import net.minecraft.client.resources.I18n;

import java.util.Random;

/** Две мини-игры: скилл-чек (ПРОБЕЛ в зелёной зоне) и последовательность стрелок. */
public class MiniGameClient {
    private static final int KEY_SPACE = 32;
    private static final int[] ARROW_KEYS = {265, 264, 263, 262}; // вверх, вниз, влево, вправо
    private static final String[] ARROWS = {"\u2191", "\u2193", "\u2190", "\u2192"};

    private static boolean active;
    private static int type;
    private static float zoneStart, zoneSize, speed;
    private static int ticks;
    private static int[] seq = new int[3];
    private static int idx;
    private static int resultTicks;
    private static boolean resultOk;

    public static void start(int t, float zs, float zsz, float spd, int seed) {
        type = t;
        zoneStart = zs;
        zoneSize = zsz;
        speed = spd;
        ticks = 0;
        idx = 0;
        Random r = new Random(seed);
        for (int i = 0; i < seq.length; i++) seq[i] = r.nextInt(4);
        active = true;
        resultTicks = 0;
    }

    public static void tick() {
        if (resultTicks > 0) resultTicks--;
        if (!active) return;
        ticks++;
        if (type == 0 && ticks * speed >= 1.05F) finish(false);
        else if (type == 1 && ticks >= 100) finish(false);
    }

    public static void onKey(int key) {
        if (!active) return;
        if (type == 0) {
            if (key == KEY_SPACE) {
                float pos = (ticks + 0.5F) * speed;
                finish(pos >= zoneStart && pos <= zoneStart + zoneSize);
            }
        } else {
            for (int i = 0; i < ARROW_KEYS.length; i++) {
                if (key == ARROW_KEYS[i]) {
                    if (i == seq[idx]) {
                        idx++;
                        if (idx >= seq.length) finish(true);
                    } else {
                        finish(false);
                    }
                    return;
                }
            }
        }
    }

    private static void finish(boolean ok) {
        active = false;
        resultOk = ok;
        resultTicks = 20;
        ModNetwork.CHANNEL.sendToServer(new MiniGameResultPacket(ok));
    }

    private static void centered(MatrixStack ms, String s, int cx, int y, int color) {
        Minecraft mc = Minecraft.getInstance();
        mc.font.drawShadow(ms, s, cx - mc.font.width(s) / 2.0F, y, color);
    }

    public static void render(MatrixStack ms, float pt, int sw, int sh) {
        int cx = sw / 2;
        int cy = sh / 2 + 40;

        if (!active) {
            if (resultTicks > 0) {
                centered(ms, I18n.get(resultOk ? "minigame.dbdgen.ok" : "minigame.dbdgen.fail"), cx, cy,
                        resultOk ? 0x55FF55 : 0xFF5555);
            }
            return;
        }

        if (type == 0) {
            int bw = 160, bx = cx - 80;
            AbstractGui.fill(ms, bx - 3, cy - 4, bx + bw + 3, cy + 14, 0xCC000000);
            AbstractGui.fill(ms, bx, cy, bx + bw, cy + 10, 0xFF333333);
            int z1 = bx + (int) (zoneStart * bw);
            int z2 = bx + (int) ((zoneStart + zoneSize) * bw);
            AbstractGui.fill(ms, z1, cy, z2, cy + 10, 0xFF22CC22);
            float pos = Math.min(1.0F, (ticks + pt) * speed);
            int mx = bx + (int) (pos * bw);
            AbstractGui.fill(ms, mx - 1, cy - 3, mx + 1, cy + 13, 0xFFFFFFFF);
            centered(ms, I18n.get("minigame.dbdgen.timing"), cx, cy - 16, 0xFFFFFF);
        } else {
            int box = 24, gap = 4;
            int total = seq.length * box + (seq.length - 1) * gap;
            int x0 = cx - total / 2;
            AbstractGui.fill(ms, x0 - 4, cy - 4, x0 + total + 4, cy + box + 12, 0xCC000000);
            for (int i = 0; i < seq.length; i++) {
                int bx = x0 + i * (box + gap);
                int col = i < idx ? 0xFF22AA22 : (i == idx ? 0xFFCCAA22 : 0xFF444444);
                AbstractGui.fill(ms, bx, cy, bx + box, cy + box, col);
                Minecraft mc = Minecraft.getInstance();
                String a = ARROWS[seq[i]];
                mc.font.drawShadow(ms, a, bx + box / 2.0F - mc.font.width(a) / 2.0F, cy + 8, 0xFFFFFF);
            }
            float left = Math.max(0F, 1F - (ticks + pt) / 100F);
            AbstractGui.fill(ms, x0, cy + box + 4, x0 + (int) (total * left), cy + box + 8, 0xFFFFFFFF);
            centered(ms, I18n.get("minigame.dbdgen.sequence"), cx, cy - 16, 0xFFFFFF);
        }
    }
}
