package com.example.dbdgen.game;

import net.minecraft.nbt.CompoundNBT;
import net.minecraft.nbt.ListNBT;
import net.minecraft.nbt.StringNBT;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.storage.WorldSavedData;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Общее состояние матча (сохраняется в мире). */
public class DbdData extends WorldSavedData {
    private static final String NAME = "dbdgen_game";
    public static final int TOTAL_GENS = 6;
    public static final String DOOR = "door";
    public static final String LEVER = "lever";
    public static final String GATE = "gate";

    private int gens = 0;
    private int survivors = 4;
    private UUID killer = null;
    private final Set<String> lootPoints = new LinkedHashSet<>();
    private final Set<String> generatorPoints = new LinkedHashSet<>();
    private final Map<String, Set<String>> points = new HashMap<>();

    public DbdData() {
        super(NAME);
    }

    public static DbdData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(DbdData::new, NAME);
    }

    public int getGens() { return gens; }
    public int getSurvivors() { return survivors; }
    public UUID getKiller() { return killer; }

    public void addGens(int n) {
        gens = Math.max(0, Math.min(TOTAL_GENS, gens + n));
        setDirty();
    }

    public void resetGens() {
        gens = 0;
        setDirty();
    }

    public void setSurvivors(int n) {
        survivors = Math.max(0, n);
        setDirty();
    }

    public void setKiller(UUID id) {
        killer = id;
        setDirty();
    }

    // ---------- точки лута ----------
    private static String key(World w, BlockPos p) {
        return w.dimension().location() + "|" + p.asLong();
    }

    public void addLoot(World w, BlockPos p) {
        if (lootPoints.add(key(w, p))) setDirty();
    }

    public void removeLoot(World w, BlockPos p) {
        if (lootPoints.remove(key(w, p))) setDirty();
    }

    public List<BlockPos> getLoot(World w) {
        String prefix = w.dimension().location() + "|";
        List<BlockPos> list = new ArrayList<>();
        for (String s : lootPoints) {
            if (s.startsWith(prefix)) list.add(BlockPos.of(Long.parseLong(s.substring(prefix.length()))));
        }
        return list;
    }

    // ---------- двери, рычаги, выходы (по категориям) ----------
    public void addPoint(String cat, World w, BlockPos p) {
        if (points.computeIfAbsent(cat, k -> new LinkedHashSet<>()).add(key(w, p))) setDirty();
    }

    public void removePoint(String cat, World w, BlockPos p) {
        Set<String> set = points.get(cat);
        if (set != null && set.remove(key(w, p))) setDirty();
    }

    public List<BlockPos> getPoints(String cat, World w) {
        List<BlockPos> list = new ArrayList<>();
        Set<String> set = points.get(cat);
        if (set == null) return list;
        String prefix = w.dimension().location() + "|";
        for (String s : set) {
            if (s.startsWith(prefix)) list.add(BlockPos.of(Long.parseLong(s.substring(prefix.length()))));
        }
        return list;
    }

    // ---------- генераторы ----------
    public void addGenerator(World w, BlockPos p) {
        if (generatorPoints.add(key(w, p))) setDirty();
    }

    public void removeGenerator(World w, BlockPos p) {
        if (generatorPoints.remove(key(w, p))) setDirty();
    }

    public List<BlockPos> getGenerators(World w) {
        String prefix = w.dimension().location() + "|";
        List<BlockPos> list = new ArrayList<>();
        for (String s : generatorPoints) {
            if (s.startsWith(prefix)) list.add(BlockPos.of(Long.parseLong(s.substring(prefix.length()))));
        }
        return list;
    }

    @Override
    public void load(CompoundNBT nbt) {
        gens = nbt.getInt("Gens");
        survivors = nbt.contains("Survivors") ? nbt.getInt("Survivors") : 4;
        killer = nbt.hasUUID("Killer") ? nbt.getUUID("Killer") : null;
        lootPoints.clear();
        ListNBT l = nbt.getList("Loot", 8);
        for (int i = 0; i < l.size(); i++) lootPoints.add(l.getString(i));
        generatorPoints.clear();
        ListNBT g = nbt.getList("Generators", 8);
        for (int i = 0; i < g.size(); i++) generatorPoints.add(g.getString(i));
        points.clear();
        CompoundNBT pts = nbt.getCompound("Points");
        for (String cat : pts.getAllKeys()) {
            ListNBT pl = pts.getList(cat, 8);
            Set<String> set = new LinkedHashSet<>();
            for (int i = 0; i < pl.size(); i++) set.add(pl.getString(i));
            points.put(cat, set);
        }
    }

    @Override
    public CompoundNBT save(CompoundNBT nbt) {
        nbt.putInt("Gens", gens);
        nbt.putInt("Survivors", survivors);
        if (killer != null) nbt.putUUID("Killer", killer);
        ListNBT l = new ListNBT();
        for (String s : lootPoints) l.add(StringNBT.valueOf(s));
        nbt.put("Loot", l);
        ListNBT g = new ListNBT();
        for (String s : generatorPoints) g.add(StringNBT.valueOf(s));
        nbt.put("Generators", g);
        CompoundNBT pts = new CompoundNBT();
        for (Map.Entry<String, Set<String>> en : points.entrySet()) {
            ListNBT pl = new ListNBT();
            for (String s : en.getValue()) pl.add(StringNBT.valueOf(s));
            pts.put(en.getKey(), pl);
        }
        nbt.put("Points", pts);
        return nbt;
    }
}
