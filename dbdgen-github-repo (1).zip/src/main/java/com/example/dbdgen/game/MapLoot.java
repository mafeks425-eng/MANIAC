package com.example.dbdgen.game;

import com.example.dbdgen.block.LootSpawnerBlock;
import com.example.dbdgen.init.ModItems;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.ItemEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.server.ServerWorld;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.function.Supplier;

/**
 * Случайный лут по карте.
 * Гарантировано: ровно одна ключ-карта и ровно столько канистр, сколько нужно на все генераторы.
 */
public final class MapLoot {
    public static final String TAG = "dbdgen_loot";

    // Одна канистра = 50 единиц, бак генератора = 100, значит 2 канистры на генератор.
    public static final int CANS_PER_GENERATOR = 2;
    public static final int CANS_TOTAL = DbdData.TOTAL_GENS * CANS_PER_GENERATOR; // 6 * 2 = 12

    private static class Entry {
        final Supplier<Item> item;
        final int weight, min, max;

        Entry(Supplier<Item> item, int weight, int min, int max) {
            this.item = item;
            this.weight = weight;
            this.min = min;
            this.max = max;
        }
    }

    // ===== СЛУЧАЙНЫЙ ЛУТ (вес = шанс). Канистр и ключ-карты тут нет: они кладутся отдельно и точно =====
    private static final List<Entry> ENTRIES = Arrays.asList(
            new Entry(ModItems.MEDKIT::get, 12, 1, 1),
            new Entry(ModItems.WRENCH::get, 10, 1, 1),
            new Entry(ModItems.CROWBAR::get, 8, 1, 1),
            new Entry(ModItems.SCISSORS::get, 8, 1, 1),
            new Entry(ModItems.BAT::get, 6, 1, 1),
            new Entry(ModItems.STUN_GUN::get, 4, 1, 1)
    );

    private MapLoot() {}

    private static ItemStack roll(Random r) {
        int total = 0;
        for (Entry e : ENTRIES) total += e.weight;
        int n = r.nextInt(total);
        for (Entry e : ENTRIES) {
            n -= e.weight;
            if (n < 0) return new ItemStack(e.item.get(), e.min + r.nextInt(e.max - e.min + 1));
        }
        return ItemStack.EMPTY;
    }

    private static class Point {
        final ServerWorld world;
        final BlockPos pos;

        Point(ServerWorld world, BlockPos pos) {
            this.world = world;
            this.pos = pos;
        }
    }

    private static List<Point> points(MinecraftServer server) {
        DbdData data = DbdData.get(server);
        List<Point> list = new ArrayList<>();
        for (ServerWorld w : server.getAllLevels()) {
            for (BlockPos p : data.getLoot(w)) {
                if (w.getBlockState(p).getBlock() instanceof LootSpawnerBlock) list.add(new Point(w, p));
                else data.removeLoot(w, p); // ящик уже сломан - забываем точку
            }
        }
        return list;
    }

    public static int count(MinecraftServer server) {
        return points(server).size();
    }

    /** Убрать весь ранее разложенный лут. */
    public static int clear(MinecraftServer server) {
        int removed = 0;
        for (ServerWorld w : server.getAllLevels()) {
            List<Entity> found = new ArrayList<>();
            for (Entity e : w.getAllEntities()) {
                if (e instanceof ItemEntity && e.getTags().contains(TAG)) found.add(e);
            }
            for (Entity e : found) {
                e.remove();
                removed++;
            }
        }
        return removed;
    }

    private static void spawn(Point pt, ItemStack stack, Random r, boolean jitter) {
        double dx = jitter ? (r.nextDouble() - 0.5) * 0.4 : 0.0;
        double dz = jitter ? (r.nextDouble() - 0.5) * 0.4 : 0.0;
        ItemEntity item = new ItemEntity(pt.world, pt.pos.getX() + 0.5 + dx, pt.pos.getY() + 1.1,
                pt.pos.getZ() + 0.5 + dz, stack);
        item.setDeltaMovement(0.0, 0.0, 0.0);
        item.setExtendedLifetime(); // не исчезает со временем
        item.addTag(TAG);
        pt.world.addFreshEntity(item);
    }

    /**
     * Разложить лут. Возвращает {число точек, число канистр}.
     * Ровно 1 ключ-карта и ровно CANS_TOTAL канистр. Если точек мало, лишние канистры
     * кладутся на случайные точки по несколько штук.
     */
    public static int[] fill(MinecraftServer server) {
        clear(server);
        List<Point> points = points(server);
        if (points.isEmpty()) return new int[]{0, 0};

        Random r = new Random();
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < points.size(); i++) order.add(i);
        Collections.shuffle(order, r);

        int keycardIdx = order.get(0);
        Set<Integer> canIdx = new HashSet<>();
        for (int k = 1; k < order.size() && canIdx.size() < CANS_TOTAL; k++) canIdx.add(order.get(k));

        for (int i = 0; i < points.size(); i++) {
            Point pt = points.get(i);
            if (i == keycardIdx) {
                spawn(pt, new ItemStack(ModItems.KEYCARD.get()), r, false);
            } else if (canIdx.contains(i)) {
                spawn(pt, new ItemStack(ModItems.FUEL_CAN.get()), r, false);
            } else {
                ItemStack stack = roll(r);
                if (!stack.isEmpty()) spawn(pt, stack, r, false);
            }
        }

        // точек меньше, чем нужно канистр: оставшиеся кладём на случайные точки
        for (int k = canIdx.size(); k < CANS_TOTAL; k++) {
            spawn(points.get(r.nextInt(points.size())), new ItemStack(ModItems.FUEL_CAN.get()), r, true);
        }
        return new int[]{points.size(), CANS_TOTAL};
    }
}
