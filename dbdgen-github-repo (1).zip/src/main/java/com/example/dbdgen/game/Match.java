package com.example.dbdgen.game;

import com.example.dbdgen.block.GeneratorBlock;
import com.example.dbdgen.network.ModNetwork;
import com.example.dbdgen.tile.GeneratorTileEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.server.MinecraftServer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.ChatType;
import net.minecraft.util.text.TranslationTextComponent;
import net.minecraft.world.server.ServerWorld;

import java.util.ArrayList;
import java.util.List;

/** Запуск нового матча одной командой: /dbd start */
public final class Match {

    public static class Result {
        public final String killerName;
        public final int survivors, generators, lootPoints, cans, levers, doors;

        Result(String killerName, int survivors, int generators, int lootPoints, int cans, int levers, int doors) {
            this.levers = levers;
            this.doors = doors;
            this.killerName = killerName;
            this.survivors = survivors;
            this.generators = generators;
            this.lootPoints = lootPoints;
            this.cans = cans;
        }
    }

    private Match() {}

    /** Возвращает null, если на сервере нет игроков. */
    public static Result start(MinecraftServer s) {
        List<ServerPlayerEntity> players = new ArrayList<>(s.getPlayerList().getPlayers());
        if (players.isEmpty()) return null;
        DbdData data = DbdData.get(s);

        // 1. все генераторы снова сломаны и пусты
        int gensReset = 0;
        for (ServerWorld w : s.getAllLevels()) {
            for (BlockPos p : data.getGenerators(w)) {
                if (!(w.getBlockState(p).getBlock() instanceof GeneratorBlock)) {
                    data.removeGenerator(w, p); // генератор уже сломан - забываем
                    continue;
                }
                TileEntity te = w.getBlockEntity(p);
                if (te instanceof GeneratorTileEntity) {
                    ((GeneratorTileEntity) te).resetAll();
                    gensReset++;
                }
            }
        }
        data.resetGens();

        // 2. жизни, стан и мини-игры у всех игроков сбрасываются, наблюдатели возвращаются в игру
        for (ServerPlayerEntity p : players) {
            GameUtil.resetLives(p);
            CompoundNBT d = GameUtil.data(p);
            d.remove("dbd_progress");
            d.remove("dbd_protect");
            d.putLong("dbd_check_end", 0);
        }

        // 3. случайный маньяк, остальные - выжившие
        ServerPlayerEntity killer = players.get(s.overworld().random.nextInt(players.size()));
        data.setKiller(killer.getUUID());
        data.setSurvivors(players.size() - 1);

        // 4. новый лут (ровно одна ключ-карта и канистры на все генераторы)
        int[] loot = MapLoot.fill(s);

        // 5. выходы закрыты, остаётся один случайный рычаг, все двери закрыты
        int levers = Exit.reset(s);
        int doors = Exit.closeDoors(s);

        ModNetwork.syncAll(s);

        s.getPlayerList().broadcastMessage(new TranslationTextComponent("message.dbdgen.match_start",
                data.getSurvivors(), DbdData.TOTAL_GENS), ChatType.SYSTEM, Util.NIL_UUID);
        killer.displayClientMessage(new TranslationTextComponent("message.dbdgen.you_killer"), false);
        killer.displayClientMessage(new TranslationTextComponent("message.dbdgen.you_killer"), true);

        return new Result(killer.getName().getString(), data.getSurvivors(), gensReset, loot[0], loot[1], levers, doors);
    }
}
