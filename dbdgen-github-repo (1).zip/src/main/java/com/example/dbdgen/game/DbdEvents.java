package com.example.dbdgen.game;

import com.example.dbdgen.DbdGen;
import com.example.dbdgen.init.ModItems;
import com.example.dbdgen.network.FlipPacket;
import com.example.dbdgen.network.ModNetwork;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraft.util.Hand;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.TranslationTextComponent;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.network.PacketDistributor;

import java.util.Random;

@Mod.EventBusSubscriber(modid = DbdGen.MODID)
public class DbdEvents {

    public static final int KILLER_STUN_TICKS = 200;      // 10 секунд
    public static final int WEAPON_COOLDOWN_TICKS = 400;  // перезарядка удара битой/ломом: 20 секунд
    public static final float MISS_CHANCE = 0.35F;        // шанс промаха по маньяку (35%)
    public static final int MISS_COOLDOWN_TICKS = 400;    // перезарядка после промаха: 20 секунд

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent e) {
        DbdCommands.register(e.getDispatcher());
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getPlayer() instanceof ServerPlayerEntity) ModNetwork.syncPlayer((ServerPlayerEntity) e.getPlayer());
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.getPlayer() instanceof ServerPlayerEntity) ModNetwork.syncPlayer((ServerPlayerEntity) e.getPlayer());
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone e) {
        CompoundNBT old = e.getOriginal().getPersistentData();
        if (old.contains(GameUtil.KEY, 10)) {
            CompoundNBT copy = old.getCompound(GameUtil.KEY).copy();
            copy.remove("dbd_hold_end");
            copy.remove("dbd_hold_kind");
            ModNetwork.CHANNEL.send(PacketDistributor.ALL.noArg(), new FlipPacket(e.getPlayer().getUUID(), false));
            e.getPlayer().getPersistentData().put(GameUtil.KEY, copy);
        }
    }

    /** Удерживаем пойманных / оглушённых игроков на месте. */
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.player.level.isClientSide) return;
        if (!(e.player instanceof ServerPlayerEntity)) return;
        ServerPlayerEntity p = (ServerPlayerEntity) e.player;
        CompoundNBT d = GameUtil.data(p);
        long end = d.getLong("dbd_hold_end");
        if (end == 0) return;
        if (p.level.getGameTime() >= end) {
            GameUtil.release(p);
            return;
        }
        double x = d.getDouble("dbd_hold_x");
        double y = d.getDouble("dbd_hold_y");
        double z = d.getDouble("dbd_hold_z");
        p.setSprinting(false);
        int holdKind = d.getInt("dbd_hold_kind");
        if (holdKind == GameUtil.KIND_WIRE || holdKind == GameUtil.KIND_SHOCK) {
            // растяжка и шокер: игрока трясёт, как от удара током
            Random r = p.level.random;
            float yaw = d.getFloat("dbd_hold_yaw") + (r.nextFloat() - 0.5F) * 24.0F;
            float pitch = MathHelper.clamp(d.getFloat("dbd_hold_pitch") + (r.nextFloat() - 0.5F) * 16.0F, -90.0F, 90.0F);
            p.connection.teleport(x + (r.nextFloat() - 0.5F) * 0.1D, y, z + (r.nextFloat() - 0.5F) * 0.1D, yaw, pitch);
            if (p.level.getGameTime() % 5 == 0) {
                p.level.broadcastEntityEvent(p, (byte) 2); // красная вспышка урона
                ((ServerWorld) p.level).sendParticles(ParticleTypes.ENCHANTED_HIT,
                        p.getX(), p.getY() + 1.0, p.getZ(), 8, 0.3, 0.6, 0.3, 0.15);
                p.level.playSound(null, p.blockPosition(), SoundEvents.PLAYER_HURT,
                        SoundCategory.PLAYERS, 0.5F, 0.5F + r.nextFloat());
            }
        } else if (p.distanceToSqr(x, y, z) > 0.25) {
            p.connection.teleport(x, y, z, p.yRot, p.xRot);
        }
    }

    /** Удар маньяка / удар битой. */
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onAttack(LivingAttackEvent e) {
        LivingEntity target = e.getEntityLiving();
        if (target.level.isClientSide) return;
        Entity src = e.getSource().getEntity();
        if (!(target instanceof ServerPlayerEntity) || !(src instanceof ServerPlayerEntity)) return;

        ServerPlayerEntity victim = (ServerPlayerEntity) target;
        ServerPlayerEntity attacker = (ServerPlayerEntity) src;
        boolean attackerKiller = GameUtil.isKiller(attacker);
        boolean victimKiller = GameUtil.isKiller(victim);
        long now = victim.level.getGameTime();

        if (attackerKiller && !victimKiller) {
            e.setCanceled(true); // обычный урон не наносим, работает система жизней
            if (GameUtil.isHeld(attacker) || victim.isSpectator()) return;
            CompoundNBT vd = GameUtil.data(victim);
            if (vd.getLong("dbd_protect") > now) return;

            vd.putLong("dbd_protect", now + 100); // 5 секунд неуязвимости
            victim.addEffect(new EffectInstance(Effects.MOVEMENT_SPEED, 100, 1)); // ускорение после удара
            // маньяк замирает и не может ударить снова
            GameUtil.startHold(attacker, attacker.getX(), attacker.getY(), attacker.getZ(), 50, false, false);

            victim.level.broadcastEntityEvent(victim, (byte) 2);
            victim.level.playSound(null, victim.blockPosition(), SoundEvents.PLAYER_HURT,
                    SoundCategory.PLAYERS, 1.0F, 0.8F);
            int lives = GameUtil.getLives(victim) - 1;
            victim.displayClientMessage(new TranslationTextComponent("message.dbdgen.hit", Math.max(0, lives)), true);
            GameUtil.setLives(victim, lives);

        } else if (!attackerKiller && victimKiller) {
            Item held = attacker.getMainHandItem().getItem();
            boolean bat = held == ModItems.BAT.get();
            boolean crowbar = held == ModItems.CROWBAR.get();
            boolean shocker = held == ModItems.STUN_GUN.get();
            if (bat || crowbar || shocker) {
                e.setCanceled(true); // урона нет, только обездвиживание
                if (!attacker.getCooldowns().isOnCooldown(held) && !GameUtil.isHeld(victim)) {
                    // шанс промахнуться: маньяк не оглушается, оружие не тратится
                    if (victim.level.random.nextFloat() < MISS_CHANCE) {
                        attacker.getCooldowns().addCooldown(held, MISS_COOLDOWN_TICKS);
                        attacker.displayClientMessage(new TranslationTextComponent("message.dbdgen.miss"), true);
                        victim.displayClientMessage(new TranslationTextComponent("message.dbdgen.dodged"), true);
                        victim.level.playSound(null, victim.blockPosition(), SoundEvents.PLAYER_ATTACK_WEAK,
                                SoundCategory.PLAYERS, 0.8F, 1.0F);
                        return;
                    }
                    if (shocker) {
                        GameUtil.startShockHold(victim, victim.getX(), victim.getY(), victim.getZ(), KILLER_STUN_TICKS);
                    } else {
                        GameUtil.startHold(victim, victim.getX(), victim.getY(), victim.getZ(),
                                KILLER_STUN_TICKS, false, false);
                    }
                    attacker.getCooldowns().addCooldown(held, WEAPON_COOLDOWN_TICKS);
                    if (crowbar || shocker) {
                        attacker.getMainHandItem().hurtAndBreak(1, attacker,
                                p -> p.broadcastBreakEvent(Hand.MAIN_HAND));
                    }
                    victim.level.playSound(null, victim.blockPosition(),
                            shocker ? SoundEvents.LIGHTNING_BOLT_IMPACT : SoundEvents.ANVIL_LAND,
                            SoundCategory.PLAYERS, 0.8F, shocker ? 1.6F : 1.2F);
                }
            }
        }
    }
}
