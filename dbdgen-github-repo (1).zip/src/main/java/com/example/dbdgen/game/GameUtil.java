package com.example.dbdgen.game;

import com.example.dbdgen.network.FlipPacket;
import com.example.dbdgen.network.ModNetwork;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.network.play.server.STitlePacket;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.Util;
import net.minecraft.util.text.ChatType;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TranslationTextComponent;
import net.minecraft.world.GameType;
import net.minecraftforge.fml.network.PacketDistributor;

public final class GameUtil {
    public static final String KEY = "PlayerPersisted";
    public static final int MAX_LIVES = 3;

    // виды ловушек
    public static final int KIND_BEAR = 1; // капкан
    public static final int KIND_ROPE = 2; // верёвка: переворачивает
    public static final int KIND_WIRE = 3; // растяжка: бьёт током
    public static final int KIND_SHOCK = 4; // электрошокер: стан током без ловушки

    private GameUtil() {}

    /** Данные игрока, которые переживают смерть. */
    public static CompoundNBT data(PlayerEntity p) {
        CompoundNBT root = p.getPersistentData();
        if (!root.contains(KEY, 10)) root.put(KEY, new CompoundNBT());
        return root.getCompound(KEY);
    }

    public static boolean isKiller(ServerPlayerEntity p) {
        MinecraftServer s = p.getServer();
        if (s == null) return false;
        return p.getUUID().equals(DbdData.get(s).getKiller());
    }

    // ---------- жизни ----------
    public static int getLives(PlayerEntity p) {
        CompoundNBT d = data(p);
        return d.contains("dbd_lives") ? d.getInt("dbd_lives") : MAX_LIVES;
    }

    public static void setLives(ServerPlayerEntity p, int lives) {
        lives = Math.max(0, Math.min(MAX_LIVES, lives));
        data(p).putInt("dbd_lives", lives);
        ModNetwork.syncPlayer(p);
        if (lives == 0) eliminate(p);
    }

    public static void resetLives(ServerPlayerEntity p) {
        data(p).putInt("dbd_lives", MAX_LIVES);
        release(p);
        if (p.isSpectator()) p.setGameMode(GameType.SURVIVAL);
        ModNetwork.syncPlayer(p);
    }

    public static void eliminate(ServerPlayerEntity p) {
        MinecraftServer s = p.getServer();
        if (s == null) return;
        DbdData d = DbdData.get(s);
        d.setSurvivors(d.getSurvivors() - 1);
        p.setGameMode(GameType.SPECTATOR);
        s.getPlayerList().broadcastMessage(new TranslationTextComponent("message.dbdgen.eliminated",
                p.getDisplayName(), d.getSurvivors()), ChatType.SYSTEM, Util.NIL_UUID);
        ModNetwork.syncAll(s);
    }

    /** Большая надпись по центру экрана у всех игроков. */
    public static void titleAll(MinecraftServer s, ITextComponent title, ITextComponent subtitle) {
        for (ServerPlayerEntity p : s.getPlayerList().getPlayers()) {
            if (subtitle != null) p.connection.send(new STitlePacket(STitlePacket.Type.SUBTITLE, subtitle, 10, 80, 20));
            p.connection.send(new STitlePacket(STitlePacket.Type.TITLE, title, 10, 80, 20));
        }
    }

    // ---------- "заморозка" (ловушки и стан маньяка) ----------
    public static void startHold(ServerPlayerEntity p, double x, double y, double z,
                                 int ticks, boolean nauseaAfter, boolean trap) {
        CompoundNBT d = data(p);
        d.putLong("dbd_hold_end", p.level.getGameTime() + ticks);
        d.putDouble("dbd_hold_x", x);
        d.putDouble("dbd_hold_y", y);
        d.putDouble("dbd_hold_z", z);
        d.putBoolean("dbd_hold_nausea", nauseaAfter);
        d.putBoolean("dbd_hold_trap", trap);
        d.putInt("dbd_hold_kind", 0);
        d.putFloat("dbd_hold_yaw", p.yRot);
        d.putFloat("dbd_hold_pitch", p.xRot);
        p.addEffect(new EffectInstance(Effects.MOVEMENT_SLOWDOWN, ticks + 5, 7, false, false, false));
        if (trap) { // пойманный светится (виден сквозь стены) всё время стана
            p.addEffect(new EffectInstance(Effects.GLOWING, ticks + 5, 0, false, false, false));
        }
    }

    /** Поймать игрока ловушкой (с тошнотой и подсветкой после стана). */
    public static void startTrapHold(ServerPlayerEntity p, double x, double y, double z, int ticks, int kind) {
        startHold(p, x, y, z, ticks, true, true);
        data(p).putInt("dbd_hold_kind", kind);
        if (kind == KIND_ROPE) {
            ModNetwork.CHANNEL.send(PacketDistributor.ALL.noArg(), new FlipPacket(p.getUUID(), true));
        }
    }

    /** Оглушить игрока током: он замирает, а камеру трясёт на всё время стана. */
    public static void startShockHold(ServerPlayerEntity p, double x, double y, double z, int ticks) {
        startHold(p, x, y, z, ticks, false, false);
        data(p).putInt("dbd_hold_kind", KIND_SHOCK);
    }

    public static boolean isHeld(ServerPlayerEntity p) {
        return data(p).getLong("dbd_hold_end") > p.level.getGameTime();
    }

    public static boolean isTrapped(ServerPlayerEntity p) {
        return isHeld(p) && data(p).getBoolean("dbd_hold_trap");
    }

    /** Отпустить игрока. Если задано - накладывается тошнота. */
    public static void release(ServerPlayerEntity p) {
        CompoundNBT d = data(p);
        if (d.getLong("dbd_hold_end") == 0) return;
        boolean nausea = d.getBoolean("dbd_hold_nausea");
        boolean trap = d.getBoolean("dbd_hold_trap");
        int kind = d.getInt("dbd_hold_kind");
        d.remove("dbd_hold_end");
        d.remove("dbd_hold_x");
        d.remove("dbd_hold_y");
        d.remove("dbd_hold_z");
        d.remove("dbd_hold_nausea");
        d.remove("dbd_hold_trap");
        p.removeEffect(Effects.MOVEMENT_SLOWDOWN);
        if (trap) p.removeEffect(Effects.GLOWING);
        d.remove("dbd_hold_kind");
        if (kind == KIND_ROPE) {
            ModNetwork.CHANNEL.send(PacketDistributor.ALL.noArg(), new FlipPacket(p.getUUID(), false));
        }
        if (nausea) p.addEffect(new EffectInstance(Effects.CONFUSION, 200, 0));
    }
}
