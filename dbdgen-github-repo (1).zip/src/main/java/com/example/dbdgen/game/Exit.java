package com.example.dbdgen.game;

import com.example.dbdgen.block.ExitGateBlock;
import com.example.dbdgen.block.ExitLeverBlock;
import com.example.dbdgen.block.KeycardDoorBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.DoorBlock;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TranslationTextComponent;
import net.minecraft.world.server.ServerWorld;

import java.util.ArrayList;
import java.util.List;

/** Побег: рычаг (один из нескольких), выходы через подвал / пещеру и запертые двери. */
public final class Exit {
    public static final int BASEMENT = 1;
    public static final int CAVE = 2;

    private static class Lever {
        final ServerWorld world;
        final BlockPos pos;

        Lever(ServerWorld world, BlockPos pos) {
            this.world = world;
            this.pos = pos;
        }
    }

    private Exit() {}

    private static List<Lever> levers(MinecraftServer s) {
        DbdData data = DbdData.get(s);
        List<Lever> list = new ArrayList<>();
        for (ServerWorld w : s.getAllLevels()) {
            for (BlockPos p : data.getPoints(DbdData.LEVER, w)) {
                if (w.getBlockState(p).getBlock() instanceof ExitLeverBlock) list.add(new Lever(w, p));
                else data.removePoint(DbdData.LEVER, w, p);
            }
        }
        return list;
    }

    /** Закрыть все выходы. */
    public static void closeGates(MinecraftServer s) {
        DbdData data = DbdData.get(s);
        for (ServerWorld w : s.getAllLevels()) {
            for (BlockPos p : data.getPoints(DbdData.GATE, w)) {
                BlockState st = w.getBlockState(p);
                if (!(st.getBlock() instanceof ExitGateBlock)) {
                    data.removePoint(DbdData.GATE, w, p);
                } else if (st.getValue(ExitGateBlock.OPEN)) {
                    w.setBlock(p, st.setValue(ExitGateBlock.OPEN, false), 3);
                }
            }
        }
    }

    /** Новый матч: выходы закрыты, из всех рычагов случайно остаётся один. Возвращает число рычагов. */
    public static int reset(MinecraftServer s) {
        closeGates(s);
        List<Lever> levers = levers(s);
        if (levers.isEmpty()) return 0;
        int chosen = s.overworld().random.nextInt(levers.size());
        for (int i = 0; i < levers.size(); i++) {
            Lever lv = levers.get(i);
            BlockState st = lv.world.getBlockState(lv.pos);
            lv.world.setBlock(lv.pos, st.setValue(ExitLeverBlock.PRESENT, i == chosen)
                    .setValue(ExitLeverBlock.PULLED, false), 3);
        }
        return levers.size();
    }

    /** Показать все рычаги (для строительства карты) и закрыть выходы. */
    public static int reveal(MinecraftServer s) {
        closeGates(s);
        List<Lever> levers = levers(s);
        for (Lever lv : levers) {
            BlockState st = lv.world.getBlockState(lv.pos);
            lv.world.setBlock(lv.pos, st.setValue(ExitLeverBlock.PRESENT, true)
                    .setValue(ExitLeverBlock.PULLED, false), 3);
        }
        return levers.size();
    }

    /** Открыть выход маршрута и оповестить всех. */
    public static void open(MinecraftServer s, int route) {
        DbdData data = DbdData.get(s);
        for (ServerWorld w : s.getAllLevels()) {
            for (BlockPos p : data.getPoints(DbdData.GATE, w)) {
                BlockState st = w.getBlockState(p);
                if (!(st.getBlock() instanceof ExitGateBlock)) continue;
                if (((ExitGateBlock) st.getBlock()).getRoute() != route) continue;
                if (!st.getValue(ExitGateBlock.OPEN)) {
                    w.setBlock(p, st.setValue(ExitGateBlock.OPEN, true), 3);
                    w.playSound(null, p, SoundEvents.PISTON_EXTEND, SoundCategory.BLOCKS, 1.0F, 0.6F);
                }
            }
        }
        String key = route == BASEMENT ? "title.dbdgen.exit_basement" : "title.dbdgen.exit_cave";
        GameUtil.titleAll(s, new TranslationTextComponent(key), new TranslationTextComponent("title.dbdgen.run"));
    }

    /** Закрыть все ключ-карточные двери. Возвращает число дверей. */
    public static int closeDoors(MinecraftServer s) {
        DbdData data = DbdData.get(s);
        int n = 0;
        for (ServerWorld w : s.getAllLevels()) {
            for (BlockPos p : data.getPoints(DbdData.DOOR, w)) {
                BlockState st = w.getBlockState(p);
                if (!(st.getBlock() instanceof KeycardDoorBlock)) {
                    data.removePoint(DbdData.DOOR, w, p);
                    continue;
                }
                n++;
                if (st.getValue(DoorBlock.OPEN)) {
                    ((KeycardDoorBlock) st.getBlock()).setOpen(w, st, p, false);
                }
            }
        }
        return n;
    }
}
