package com.example.dbdgen.game;

import com.example.dbdgen.network.ModNetwork;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.command.CommandSource;
import net.minecraft.command.Commands;
import net.minecraft.command.arguments.EntityArgument;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.TranslationTextComponent;

import java.util.ArrayList;
import java.util.List;

public class DbdCommands {

    public static void register(CommandDispatcher<CommandSource> d) {
        d.register(Commands.literal("dbd").requires(s -> s.hasPermission(2))
                .then(Commands.literal("gens")
                        .then(Commands.literal("add")
                                .executes(c -> addGens(c.getSource(), 1))
                                .then(Commands.argument("amount", IntegerArgumentType.integer(1, DbdData.TOTAL_GENS))
                                        .executes(c -> addGens(c.getSource(), IntegerArgumentType.getInteger(c, "amount")))))
                        .then(Commands.literal("reset").executes(c -> resetGens(c.getSource()))))
                .then(Commands.literal("survivors")
                        .executes(c -> showSurvivors(c.getSource()))
                        .then(Commands.literal("set")
                                .then(Commands.argument("amount", IntegerArgumentType.integer(0, 99))
                                        .executes(c -> setSurvivors(c.getSource(), IntegerArgumentType.getInteger(c, "amount"))))))
                .then(Commands.literal("killer")
                        .then(Commands.literal("clear").executes(c -> setKiller(c.getSource(), null)))
                        .then(Commands.literal("random").executes(c -> randomKiller(c.getSource())))
                        .then(Commands.argument("player", EntityArgument.player())
                                .executes(c -> setKiller(c.getSource(), EntityArgument.getPlayer(c, "player")))))
                .then(Commands.literal("lives")
                        .then(Commands.literal("reset")
                                .executes(c -> resetLives(c.getSource(), null))
                                .then(Commands.argument("player", EntityArgument.player())
                                        .executes(c -> resetLives(c.getSource(), EntityArgument.getPlayer(c, "player"))))))
                .then(Commands.literal("start").executes(c -> startMatch(c.getSource())))
                .then(Commands.literal("exit")
                        .then(Commands.literal("reveal").executes(c -> exitReveal(c.getSource())))
                        .then(Commands.literal("open")
                                .then(Commands.literal("basement").executes(c -> exitOpen(c.getSource(), Exit.BASEMENT)))
                                .then(Commands.literal("cave").executes(c -> exitOpen(c.getSource(), Exit.CAVE)))))
                .then(Commands.literal("loot")
                        .then(Commands.literal("fill").executes(c -> fillLoot(c.getSource())))
                        .then(Commands.literal("clear").executes(c -> clearLoot(c.getSource())))
                        .then(Commands.literal("count").executes(c -> countLoot(c.getSource()))))
                .then(Commands.literal("status").executes(c -> status(c.getSource()))));
    }

    private static int addGens(CommandSource src, int n) {
        MinecraftServer s = src.getServer();
        DbdData d = DbdData.get(s);
        d.addGens(n);
        ModNetwork.syncAll(s);
        src.sendSuccess(new TranslationTextComponent("cmd.dbdgen.gens", d.getGens(), DbdData.TOTAL_GENS), true);
        return d.getGens();
    }

    private static int resetGens(CommandSource src) {
        MinecraftServer s = src.getServer();
        DbdData.get(s).resetGens();
        ModNetwork.syncAll(s);
        src.sendSuccess(new TranslationTextComponent("cmd.dbdgen.gens_reset"), true);
        return 1;
    }

    private static int showSurvivors(CommandSource src) {
        int n = DbdData.get(src.getServer()).getSurvivors();
        src.sendSuccess(new TranslationTextComponent("cmd.dbdgen.survivors", n), false);
        return n;
    }

    private static int setSurvivors(CommandSource src, int n) {
        MinecraftServer s = src.getServer();
        DbdData.get(s).setSurvivors(n);
        ModNetwork.syncAll(s);
        src.sendSuccess(new TranslationTextComponent("cmd.dbdgen.survivors", n), true);
        return n;
    }

    private static int setKiller(CommandSource src, ServerPlayerEntity p) {
        MinecraftServer s = src.getServer();
        DbdData.get(s).setKiller(p == null ? null : p.getUUID());
        ModNetwork.syncAll(s);
        if (p == null) src.sendSuccess(new TranslationTextComponent("cmd.dbdgen.killer_clear"), true);
        else src.sendSuccess(new TranslationTextComponent("cmd.dbdgen.killer_set", p.getName().getString()), true);
        return 1;
    }

    /** Случайный маньяк среди игроков онлайн (наблюдатели не участвуют). Знает об этом только он сам. */
    private static int randomKiller(CommandSource src) {
        MinecraftServer s = src.getServer();
        List<ServerPlayerEntity> list = new ArrayList<>();
        for (ServerPlayerEntity p : s.getPlayerList().getPlayers()) {
            if (!p.isSpectator()) list.add(p);
        }
        if (list.isEmpty()) {
            src.sendFailure(new TranslationTextComponent("cmd.dbdgen.killer_nobody"));
            return 0;
        }
        ServerPlayerEntity k = list.get(s.overworld().random.nextInt(list.size()));
        DbdData.get(s).setKiller(k.getUUID());
        ModNetwork.syncAll(s);
        k.displayClientMessage(new TranslationTextComponent("message.dbdgen.you_killer"), false);
        k.displayClientMessage(new TranslationTextComponent("message.dbdgen.you_killer"), true);
        src.sendSuccess(new TranslationTextComponent("cmd.dbdgen.killer_set", k.getName().getString()), false);
        return 1;
    }

    private static int resetLives(CommandSource src, ServerPlayerEntity only) {
        MinecraftServer s = src.getServer();
        if (only != null) {
            GameUtil.resetLives(only);
        } else {
            for (ServerPlayerEntity p : s.getPlayerList().getPlayers()) GameUtil.resetLives(p);
        }
        src.sendSuccess(new TranslationTextComponent("cmd.dbdgen.lives_reset"), true);
        return 1;
    }

    private static int exitReveal(CommandSource src) {
        int n = Exit.reveal(src.getServer());
        src.sendSuccess(new TranslationTextComponent("cmd.dbdgen.exit_reveal", n), true);
        return n;
    }

    private static int exitOpen(CommandSource src, int route) {
        Exit.open(src.getServer(), route);
        src.sendSuccess(new TranslationTextComponent("cmd.dbdgen.exit_open"), true);
        return 1;
    }

    private static int startMatch(CommandSource src) {
        Match.Result r = Match.start(src.getServer());
        if (r == null) {
            src.sendFailure(new TranslationTextComponent("cmd.dbdgen.killer_nobody"));
            return 0;
        }
        src.sendSuccess(new TranslationTextComponent("cmd.dbdgen.start", r.survivors, r.generators, r.lootPoints), false);
        src.sendSuccess(new TranslationTextComponent("cmd.dbdgen.killer_set", r.killerName), false);
        src.sendSuccess(new TranslationTextComponent("cmd.dbdgen.start_exit", r.levers, r.doors), false);
        if (r.levers == 0) src.sendSuccess(new TranslationTextComponent("cmd.dbdgen.no_levers"), false);
        if (r.generators == 0 || r.lootPoints == 0) {
            src.sendSuccess(new TranslationTextComponent("cmd.dbdgen.start_warn", r.generators, r.lootPoints), false);
        }
        return 1;
    }

    private static int fillLoot(CommandSource src) {
        int[] r = MapLoot.fill(src.getServer());
        if (r[0] == 0) {
            src.sendFailure(new TranslationTextComponent("cmd.dbdgen.loot_none"));
            return 0;
        }
        src.sendSuccess(new TranslationTextComponent("cmd.dbdgen.loot_fill", r[0], r[1]), true);
        if (r[0] < r[1] + 1) {
            src.sendSuccess(new TranslationTextComponent("cmd.dbdgen.loot_few", r[1] + 1), false);
        }
        return r[0];
    }

    private static int clearLoot(CommandSource src) {
        int n = MapLoot.clear(src.getServer());
        src.sendSuccess(new TranslationTextComponent("cmd.dbdgen.loot_clear", n), true);
        return n;
    }

    private static int countLoot(CommandSource src) {
        int n = MapLoot.count(src.getServer());
        src.sendSuccess(new TranslationTextComponent("cmd.dbdgen.loot_count", n), false);
        return n;
    }

    private static int status(CommandSource src) {
        DbdData d = DbdData.get(src.getServer());
        src.sendSuccess(new TranslationTextComponent("cmd.dbdgen.status",
                d.getGens(), DbdData.TOTAL_GENS, d.getSurvivors()), false);
        return 1;
    }
}
