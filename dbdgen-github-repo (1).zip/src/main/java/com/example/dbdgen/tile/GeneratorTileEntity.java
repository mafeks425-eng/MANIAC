package com.example.dbdgen.tile;

import com.example.dbdgen.block.GeneratorBlock;
import com.example.dbdgen.game.DbdData;
import com.example.dbdgen.game.GameUtil;
import com.example.dbdgen.init.ModTileEntities;
import com.example.dbdgen.network.MiniGamePacket;
import com.example.dbdgen.network.ModNetwork;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.server.MinecraftServer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.Util;
import net.minecraft.util.text.ChatType;
import net.minecraft.util.text.TranslationTextComponent;
import net.minecraftforge.fml.network.PacketDistributor;

import java.util.Random;

public class GeneratorTileEntity extends TileEntity {

    // ===== НАСТРОЙКИ =====
    public static final int MAX_FUEL = 100;            // бак в процентах
    public static final int MAX_REPAIR = 100;
    public static final int HAND_REPAIR = 1;           // прогресс за нажатие руками
    public static final int WRENCH_REPAIR = 3;         // прогресс за нажатие ключом
    public static final int PROGRESS_PER_CHECK = 25;   // мини-игра каждые N% прогресса
    public static final int CHECK_SUCCESS_BONUS = 6;
    public static final int CHECK_FAIL_PENALTY = 8;
    // =====================

    private int fuel = 0;
    private int repair = 0;
    private boolean counted = false;

    public GeneratorTileEntity() {
        super(ModTileEntities.GENERATOR.get());
    }

    public int getFuel() { return fuel; }
    public int getRepair() { return repair; }
    public boolean isRepaired() { return repair >= MAX_REPAIR; }

    public void addFuel(int n) {
        fuel = Math.max(0, Math.min(MAX_FUEL, fuel + n));
        setChanged();
        updateState();
    }

    public void addRepair(int n) {
        repair = Math.max(0, Math.min(MAX_REPAIR, repair + n));
        setChanged();
        updateState();
        if (repair >= MAX_REPAIR && !counted) onRepaired();
    }

    /** Один шаг ремонта (вызывается пока игрок держит ПКМ). */
    public void repairStep(ServerPlayerEntity p, boolean wrench) {
        if (level == null) return;
        long now = level.getGameTime();
        CompoundNBT d = GameUtil.data(p);

        // игрок не ответил на мини-игру вовремя - провал
        long end = d.getLong("dbd_check_end");
        if (end != 0 && end < now) {
            d.putLong("dbd_check_end", 0);
            addRepair(-CHECK_FAIL_PENALTY);
        }

        int amount = wrench ? WRENCH_REPAIR : HAND_REPAIR;
        addRepair(amount);
        level.playSound(null, worldPosition, SoundEvents.CHAIN_HIT, SoundCategory.BLOCKS,
                1.0F, (wrench ? 1.2F : 0.8F) + level.random.nextFloat() * 0.4F);

        if (isRepaired()) {
            level.playSound(null, worldPosition, SoundEvents.ANVIL_USE, SoundCategory.BLOCKS, 0.8F, 1.2F);
            p.displayClientMessage(new TranslationTextComponent("message.dbdgen.repaired"), true);
            return;
        }

        int progress = d.getInt("dbd_progress") + amount;
        if (progress >= PROGRESS_PER_CHECK && d.getLong("dbd_check_end") == 0) {
            progress = 0;
            startCheck(p, d, now);
        }
        d.putInt("dbd_progress", progress);
        p.displayClientMessage(new TranslationTextComponent("message.dbdgen.repair", repair), true);
    }

    private void startCheck(ServerPlayerEntity p, CompoundNBT d, long now) {
        Random r = level.random;
        int type = r.nextInt(100) < 65 ? 0 : 1;
        d.putLong("dbd_check_end", now + 200);
        d.putLong("dbd_check_pos", worldPosition.asLong());
        float zoneStart = 0.45F + r.nextFloat() * 0.35F;
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p),
                new MiniGamePacket(type, zoneStart, 0.13F, 0.022F, r.nextInt()));
    }

    public void applyCheckResult(ServerPlayerEntity p, boolean success) {
        if (level == null) return;
        if (success) {
            level.playSound(null, worldPosition, SoundEvents.EXPERIENCE_ORB_PICKUP, SoundCategory.BLOCKS, 1.0F, 1.2F);
            addRepair(CHECK_SUCCESS_BONUS);
            if (!isRepaired()) p.displayClientMessage(new TranslationTextComponent("message.dbdgen.check_ok"), true);
        } else {
            level.playSound(null, worldPosition, SoundEvents.ANVIL_LAND, SoundCategory.BLOCKS, 0.7F, 0.6F);
            addRepair(-CHECK_FAIL_PENALTY);
            p.displayClientMessage(new TranslationTextComponent("message.dbdgen.check_fail"), true);
        }
    }

    private void onRepaired() {
        counted = true;
        setChanged();
        if (level == null || level.isClientSide) return;
        MinecraftServer server = level.getServer();
        if (server == null) return;
        DbdData data = DbdData.get(server);
        data.addGens(1);
        server.getPlayerList().broadcastMessage(new TranslationTextComponent("message.dbdgen.gen_done",
                data.getGens(), DbdData.TOTAL_GENS), ChatType.SYSTEM, Util.NIL_UUID);
        if (data.getGens() >= DbdData.TOTAL_GENS) {
            server.getPlayerList().broadcastMessage(new TranslationTextComponent("message.dbdgen.all_done"),
                    ChatType.SYSTEM, Util.NIL_UUID);
            GameUtil.titleAll(server, new TranslationTextComponent("title.dbdgen.power_restored"),
                    new TranslationTextComponent("title.dbdgen.find_lever"));
        }
        ModNetwork.syncAll(server);
    }

    /** Сброс к началу матча: пустой бак, генератор сломан, в счётчик заново не засчитан. */
    public void resetAll() {
        fuel = 0;
        repair = 0;
        counted = false;
        setChanged();
        updateState();
    }

    private void updateState() {
        if (level == null || level.isClientSide) return;
        BlockState s = getBlockState();
        boolean lit = repair >= MAX_REPAIR;
        boolean fueled = fuel >= MAX_FUEL;
        if (s.getValue(GeneratorBlock.LIT) != lit || s.getValue(GeneratorBlock.FUELED) != fueled) {
            level.setBlock(worldPosition, s.setValue(GeneratorBlock.LIT, lit).setValue(GeneratorBlock.FUELED, fueled), 3);
        }
    }

    @Override
    public void load(BlockState state, CompoundNBT nbt) {
        super.load(state, nbt);
        fuel = nbt.getInt("Fuel");
        repair = nbt.getInt("Repair");
        counted = nbt.getBoolean("Counted");
    }

    @Override
    public CompoundNBT save(CompoundNBT nbt) {
        super.save(nbt);
        nbt.putInt("Fuel", fuel);
        nbt.putInt("Repair", repair);
        nbt.putBoolean("Counted", counted);
        return nbt;
    }
}
