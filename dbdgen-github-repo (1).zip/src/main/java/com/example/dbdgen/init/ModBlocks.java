package com.example.dbdgen.init;

import com.example.dbdgen.DbdGen;
import com.example.dbdgen.block.ExitGateBlock;
import com.example.dbdgen.block.ExitLeverBlock;
import com.example.dbdgen.block.GeneratorBlock;
import com.example.dbdgen.block.KeycardDoorBlock;
import com.example.dbdgen.block.LootSpawnerBlock;
import com.example.dbdgen.block.TrapBlock;
import com.example.dbdgen.game.Exit;
import com.example.dbdgen.game.GameUtil;
import net.minecraft.block.Block;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, DbdGen.MODID);

    public static final RegistryObject<Block> GENERATOR =
            BLOCKS.register("generator", GeneratorBlock::new);

    // Ловушки маньяка: (время стана в тиках, форма)
    public static final RegistryObject<Block> BEAR_TRAP =
            BLOCKS.register("bear_trap", () -> new TrapBlock(300, Block.box(1, 0, 1, 15, 3, 15), GameUtil.KIND_BEAR));
    public static final RegistryObject<Block> ROPE_TRAP =
            BLOCKS.register("rope_trap", () -> new TrapBlock(240, Block.box(3, 0, 3, 13, 2, 13), GameUtil.KIND_ROPE));
    public static final RegistryObject<Block> TRIPWIRE_TRAP =
            BLOCKS.register("tripwire_trap", () -> new TrapBlock(200, Block.box(1, 0, 6, 15, 5, 10), GameUtil.KIND_WIRE));

    // Побег: рычаги и выходы двух маршрутов
    public static final RegistryObject<Block> EXIT_LEVER_BASEMENT =
            BLOCKS.register("exit_lever_basement", () -> new ExitLeverBlock(Exit.BASEMENT));
    public static final RegistryObject<Block> EXIT_LEVER_CAVE =
            BLOCKS.register("exit_lever_cave", () -> new ExitLeverBlock(Exit.CAVE));
    public static final RegistryObject<Block> EXIT_GATE_BASEMENT =
            BLOCKS.register("exit_gate_basement", () -> new ExitGateBlock(Exit.BASEMENT));
    public static final RegistryObject<Block> EXIT_GATE_CAVE =
            BLOCKS.register("exit_gate_cave", () -> new ExitGateBlock(Exit.CAVE));

    public static final RegistryObject<Block> LOOT_SPAWNER =
            BLOCKS.register("loot_spawner", LootSpawnerBlock::new);

    public static final RegistryObject<Block> KEYCARD_DOOR =
            BLOCKS.register("keycard_door", KeycardDoorBlock::new);
}
