package com.example.dbdgen.init;

import com.example.dbdgen.DbdGen;
import com.example.dbdgen.item.CrowbarItem;
import com.example.dbdgen.item.MedkitItem;
import com.example.dbdgen.item.ScissorsItem;
import com.example.dbdgen.item.TrapItem;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.TallBlockItem;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, DbdGen.MODID);

    private static Item.Properties props(ItemGroup g) {
        return new Item.Properties().tab(g);
    }

    public static final RegistryObject<Item> GENERATOR = ITEMS.register("generator",
            () -> new BlockItem(ModBlocks.GENERATOR.get(), props(ItemGroup.TAB_DECORATIONS)));

    public static final RegistryObject<Item> EXIT_LEVER_BASEMENT = ITEMS.register("exit_lever_basement",
            () -> new BlockItem(ModBlocks.EXIT_LEVER_BASEMENT.get(), props(ItemGroup.TAB_REDSTONE)));
    public static final RegistryObject<Item> EXIT_LEVER_CAVE = ITEMS.register("exit_lever_cave",
            () -> new BlockItem(ModBlocks.EXIT_LEVER_CAVE.get(), props(ItemGroup.TAB_REDSTONE)));
    public static final RegistryObject<Item> EXIT_GATE_BASEMENT = ITEMS.register("exit_gate_basement",
            () -> new BlockItem(ModBlocks.EXIT_GATE_BASEMENT.get(), props(ItemGroup.TAB_REDSTONE)));
    public static final RegistryObject<Item> EXIT_GATE_CAVE = ITEMS.register("exit_gate_cave",
            () -> new BlockItem(ModBlocks.EXIT_GATE_CAVE.get(), props(ItemGroup.TAB_REDSTONE)));

    public static final RegistryObject<Item> LOOT_SPAWNER = ITEMS.register("loot_spawner",
            () -> new BlockItem(ModBlocks.LOOT_SPAWNER.get(), props(ItemGroup.TAB_DECORATIONS)));

    public static final RegistryObject<Item> KEYCARD_DOOR = ITEMS.register("keycard_door",
            () -> new TallBlockItem(ModBlocks.KEYCARD_DOOR.get(), props(ItemGroup.TAB_REDSTONE)));

    // Канистра: 50 единиц топлива (бак = 100, то есть нужно 2 канистры)
    public static final RegistryObject<Item> FUEL_CAN = ITEMS.register("fuel_can",
            () -> new Item(props(ItemGroup.TAB_MISC).durability(50)));

    public static final RegistryObject<Item> WRENCH = ITEMS.register("wrench",
            () -> new Item(props(ItemGroup.TAB_TOOLS).stacksTo(1)));

    public static final RegistryObject<Item> CROWBAR = ITEMS.register("crowbar",
            () -> new CrowbarItem(props(ItemGroup.TAB_TOOLS).durability(5)));

    public static final RegistryObject<Item> SCISSORS = ITEMS.register("scissors",
            () -> new ScissorsItem(props(ItemGroup.TAB_TOOLS).durability(10)));

    public static final RegistryObject<Item> BAT = ITEMS.register("bat",
            () -> new Item(props(ItemGroup.TAB_COMBAT).stacksTo(1)));

    // Электрошокер: оглушает маньяка током (камеру трясёт на время стана)
    public static final RegistryObject<Item> STUN_GUN = ITEMS.register("stun_gun",
            () -> new Item(props(ItemGroup.TAB_COMBAT).durability(4)));

    public static final RegistryObject<Item> KEYCARD = ITEMS.register("keycard",
            () -> new Item(props(ItemGroup.TAB_MISC).stacksTo(1)));

    public static final RegistryObject<Item> MEDKIT = ITEMS.register("medkit",
            () -> new MedkitItem(props(ItemGroup.TAB_MISC).stacksTo(4)));

    // Ловушки: не расходуются, но после установки уходят на перезарядку (в тиках)
    public static final RegistryObject<Item> BEAR_TRAP = ITEMS.register("bear_trap",
            () -> new TrapItem(ModBlocks.BEAR_TRAP.get(), props(ItemGroup.TAB_MISC).stacksTo(1), 600));
    public static final RegistryObject<Item> ROPE_TRAP = ITEMS.register("rope_trap",
            () -> new TrapItem(ModBlocks.ROPE_TRAP.get(), props(ItemGroup.TAB_MISC).stacksTo(1), 400));
    public static final RegistryObject<Item> TRIPWIRE_TRAP = ITEMS.register("tripwire_trap",
            () -> new TrapItem(ModBlocks.TRIPWIRE_TRAP.get(), props(ItemGroup.TAB_MISC).stacksTo(1), 300));
}
